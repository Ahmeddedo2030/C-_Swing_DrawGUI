package swingpack;

import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class readChildProcess {

	private ControlGUI cg;
	private JFrameInitialisation initial;
	private InputOutputStream inout;
	private SubProcess sp;
	
	
	public readChildProcess(ControlGUI cg, JFrameInitialisation initial, InputOutputStream inout, SubProcess sp) {

		this.cg = cg;
		this.initial = initial;
		this.inout = inout;
		this.sp = sp;

	}

	public void readChildProcessStream(String path) throws IOException, InterruptedException {

		sp.createSubProcess(path);

		inout.setInputStream(sp.childProcess.getInputStream());  // lesen die Inputstreams des Child-Prozesses

//		 while (sp.childProcess.isAlive()) {
//		
//		 System.out.println("aktiv");
//		
//		 }

		String line;

		while ((line = inout.getInputStream().readLine()) != null) {

			try {

				inout.controlInputOutputStream(line, initial.frame);
			}

			catch (XYCoordinatesException e) {
				
				// X,y-Koordinaten werden �berschritten
				SwingUtilities.invokeLater(new Runnable() {  // Warten bis Swing fertig ist
					
					@Override
					public void run() {  
						// TODO Auto-generated method stub
						JOptionPane.showMessageDialog(null,"M�gliche X oder Y Koordinate wurde die Gr��e ihres JPanels �berschritten oder weniger als 0, bitte geben Sie nochmal die richtigen Koordinaten ein",
						"Warning",2);
					}
				});

				sp.killSubProcess(); // Kindprozess eliminieren
				cg.fillPixelListZero(cg.getWidth(),cg.getHeight()); // Filling the Pixellist Array with the Background Color

				return;
				
			}

		}

			cg.render();
			cg.repaint();
			
	}

}

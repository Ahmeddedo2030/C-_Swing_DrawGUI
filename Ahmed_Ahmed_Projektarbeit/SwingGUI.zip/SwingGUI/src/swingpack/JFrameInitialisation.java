package swingpack;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class JFrameInitialisation {

	private JMenuBar jmbar;
	public JFrame frame;
	private JFrameListener jfactlis;

	public JFrameInitialisation(ControlGUI cg,JFrameListener jfactlis) {

		this.jfactlis = jfactlis;
		frame = new JFrame();
		frame.setSize(800, 600);
		createToolbar();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Drawing GUI");
		frame.setLocation(70, 70);
		frame.setResizable(true);
		frame.getContentPane().add(cg);
		frame.setVisible(true);
		frame.setJMenuBar(jmbar);
		frame.addMouseMotionListener(jfactlis);
		
	}

	protected void createToolbar() {

		JMenuItem one, two, three;
		JMenu zoomjmenu;
		JButton clearbutton;
		JButton choosebutton;
		JButton killprocessbutton;

		jmbar = new JMenuBar();

		zoomjmenu = new JMenu("Zoom Level");

		clearbutton = new JButton("Clear");
		clearbutton.setContentAreaFilled(false);
		clearbutton.setBorderPainted(false);
		clearbutton.setFocusable(false);

		choosebutton = new JButton("Choose compiled File");
		choosebutton.setContentAreaFilled(false);
		choosebutton.setBorderPainted(false);
		choosebutton.setFocusable(false);

		killprocessbutton = new JButton("Kill Subprocess");
		killprocessbutton.setContentAreaFilled(false);
		killprocessbutton.setBorderPainted(false);
		killprocessbutton.setFocusable(false);

		jmbar.add(zoomjmenu);
		jmbar.add(clearbutton);
		jmbar.add(choosebutton);
		jmbar.add(killprocessbutton);
		
		one = new JMenuItem("1");
		one.addActionListener(jfactlis);
		one.setActionCommand("one");
		zoomjmenu.add(one);

		two = new JMenuItem("2");
		two.addActionListener(jfactlis);
		two.setActionCommand("two");
		zoomjmenu.add(two);

		three = new JMenuItem("3");
		three.addActionListener(jfactlis);
		three.setActionCommand("three");
		zoomjmenu.add(three);
		
		clearbutton.addActionListener(jfactlis);
		clearbutton.setActionCommand("clear");

		choosebutton.addActionListener(jfactlis);
		choosebutton.setActionCommand("choose");

		killprocessbutton.addActionListener(jfactlis);
		killprocessbutton.setActionCommand("killsubprocess");

	}

}

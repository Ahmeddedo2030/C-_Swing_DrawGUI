package swingpack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import javax.swing.JFrame;

public class InputOutputStream {

	private ControlGUI cg;
	private SubProcess sp;
	private BufferedReader br = null;
	private BufferedWriter bw = null;

	public InputOutputStream(ControlGUI cg, SubProcess sp) {

		this.cg = cg;
		this.sp = sp;

	}

	public void setInputStream(InputStream inputStream) {
		this.br = new BufferedReader(new InputStreamReader(inputStream));
	}
	
	public BufferedReader getInputStream() {
		
		return br;
	}

	public void setOutputStream(OutputStream outputStream) {
		this.bw = new BufferedWriter(new OutputStreamWriter(outputStream));
	}
	
	public BufferedWriter getOutputStream() {
		
		return bw;
	}

	public void controlInputOutputStream(String value, JFrame jf) throws IOException, XYCoordinatesException {

		setOutputStream(sp.childProcess.getOutputStream()); // Schicken das Stream zum Kindprozess

		if (value.length() == 12) { // Stringvalue enth�lt X,Y,R,G,B Werte in HEX

			int x = Integer.parseInt(value.substring(0, 3), 16); // x ist 12 Bits
			int y = Integer.parseInt(value.substring(3, 6), 16); // y ist 12 Bits
			int red = Integer.parseInt(value.substring(6, 8), 16); // red ist 8 Bits bis 255
			int green = Integer.parseInt(value.substring(8, 10), 16); // green ist 8 Bits bis 255
			int blue = Integer.parseInt(value.substring(10, 12), 16); // blue ist 8 Bits bis 255

			if (x > cg.getWidth() - 1 || y > cg.getHeight() - 1 || x < 0
					|| y < 0) {    /*
								    * Exception werfen, wenn x und/oder y Koordinaten �berschritten werden
								    */

				throw new XYCoordinatesException();

			} else {

				cg.pixellist[x][y] = cg.getIntRGB(red, green, blue); // Alle RGB-Werte in einem Integer zusammenf�gen

			}

		} else if (value.length() == 6) { // Stringvalue enth�lt nur X,Y-Werte in HEX

			int x = Integer.parseInt(value.substring(0, 3), 16);
			int y = Integer.parseInt(value.substring(3, 6), 16);

			if (x > cg.getWidth() - 1 || y > cg.getHeight() - 1) {

				throw new XYCoordinatesException();

			} else {

				getOutputStream().write(cg.getPixel(x, y) + "\n");
				getOutputStream().flush();

			}

		} else if (value.indexOf(',') != -1) { // Stringvalue enth�lt RGB-Werte R,G,B in Decimal

			System.out.println(value);

		} else if (value.equals("H")) { // Stringvalue enth�lt Height-Wert in Decimal

			getOutputStream().write(cg.getHeight() + "\n");
			getOutputStream().flush();

		} else if (value.equals("W")) { // Stringvalue enth�lt Width-Wert in Decimal

			getOutputStream().write(cg.getWidth() + "\n");
			getOutputStream().flush();

		}
	}

}

class XYCoordinatesException extends Exception { 
    
	private static final long serialVersionUID = 1L;

	public XYCoordinatesException() {
        
    }
}

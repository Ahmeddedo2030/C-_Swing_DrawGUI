package swingpack;

import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.KeyStroke;

public class JFrameListener implements java.awt.event.ActionListener, MouseMotionListener {

	private ControlGUI cg;
	private SubProcess sp;
	private String path;
	private boolean childprocessalivebool = false;

	public JFrameListener(ControlGUI cg, SubProcess sp) {

		this.cg = cg;
		this.sp = sp;

		cg.getInputMap().put(KeyStroke.getKeyStroke('+'), "Zoomin");

		cg.getActionMap().put("Zoomin", new AbstractAction() {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(cg.xyzoomlevel < cg.maxzoomlevel) {
				
				cg.xyzoomlevel++;
				cg.centerbool = false;
				cg.repaint();
				
				}
				
			}
		});
		
		cg.getInputMap().put(KeyStroke.getKeyStroke('-'), "Zoomout");

		cg.getActionMap().put("Zoomout", new AbstractAction() {

			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {

				if(cg.xyzoomlevel > cg.minzoomlevel) {
					
					cg.xyzoomlevel--;
					cg.centerbool = false;
					cg.repaint();
					
					}

			}
		});
	}
	
	public String getPath() {
		
		return path;
	}
	
	public void setPath(String path) {
		
		this.path = path;
		
	}

	@Override
	public void actionPerformed(ActionEvent e) { // Warten eine Aktion von dem Nutzer

		String command = e.getActionCommand();

		if (command.equals("one")) { // Zoomlevel ausw�hlen

			cg.centerzoomlevel = 1;
			cg.xyzoomlevel = 1;
			cg.centerbool = true;
			cg.repaint();

		} else if (command.equals("two")) { // Zoomlevel ausw�hlen

			cg.centerzoomlevel = 2;
			cg.xyzoomlevel = 2;
			cg.centerbool = true;
			cg.repaint();

		} else if (command.equals("three")) { // Zoomlevel ausw�hlen

			cg.centerzoomlevel = 3;
			cg.xyzoomlevel = 3;
			cg.centerbool = true;
			cg.repaint();

		} else if (command.equals("clear")) { // Zeichnung l�schen

			cg.clearGUI();

		} else if (command.equals("choose")) {  // Eine kompilierte Datei ausw�hlen
			
			String currentDir = System.getProperty("user.dir");   // Working-Directory abholen

			JFileChooser jfc = new JFileChooser(currentDir);
			
			int returnValue = jfc.showOpenDialog(null);

			if (returnValue == JFileChooser.APPROVE_OPTION) {

				File selectedFile = jfc.getSelectedFile();
 
				setPath(selectedFile.getAbsolutePath());

				try {
					
					if(childprocessalivebool == true) {    // Falls einen laufend Subprozess gibt, wird es get�tet
						
						try {
							
							if(sp.childProcess.isAlive()) {
								
							sp.killSubProcess();
							
							}
							
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
					
					childprocessalivebool = true;

					Main.exec();

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		} else if (command.equals("killsubprocess")) { // Kindprozess eliminieren

			try {

				sp.killSubProcess();

			}

			catch (NullPointerException e1) {

			} catch (InterruptedException e1) {

				e1.printStackTrace();
			}
		}

	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {

		cg.mouseX = e.getX(); // X Koordinate des Jpanels ermitteln
		cg.mouseY = e.getY();  // Y Koordinate des Jpanels ermitteln

	}

}

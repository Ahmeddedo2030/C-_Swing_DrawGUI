package swingpack;

import java.io.IOException;

import javax.swing.JOptionPane;

public class Main {

	private static ControlGUI cg;
	private static JFrameInitialisation in;
	private static JFrameListener jfactlis;
	private static readChildProcess rchproc;

	public static void main(String[] args) {

		Start();

	}

	public static void Start() {

		cg = new ControlGUI();
		SubProcess sp = new SubProcess();
		InputOutputStream inout = new InputOutputStream(cg, sp);
		jfactlis = new JFrameListener(cg, sp);
		in = new JFrameInitialisation(cg, jfactlis);
		rchproc = new readChildProcess(cg, in, inout, sp);
		cg.pixellist = new int[cg.getWidth()][cg.getHeight()];
		cg.fillPixelListZero(cg.getWidth(),cg.getHeight());
	}

	public static void exec() throws IOException {

		cg.pixellisttmp = new int[cg.getWidth()][cg.getHeight()];
		cg.fillPixelListtmpZero(cg.getWidth(), cg.getHeight());      // Pixellisttmp wird mit der Hintergrundfarbe ausgef�llt
																 
		cg.copyPixelsinPixellisttmp(cg.pixellist, cg.pixellisttmp);  // Kopieren die Pixel vorl�ufig vom Pixellist im Pixellisttmp
																	
		cg.pixellist = new int[cg.getWidth()][cg.getHeight()];
		cg.fillPixelListZero(cg.getWidth(),cg.getHeight());          // Pixellist wird mit der Hintergrundfarbe ausgef�llt
		cg.copyPixelsinPixellist(cg.pixellist, cg.pixellisttmp);     // Kopieren die Pixel vom Pixellisttmp im Pixellist zur�ck

		Thread t = new Thread(new Runnable() {     // Lesen des Kindprozesses im neuen Thread

			@Override
			public void run() {

				try {

					rchproc.readChildProcessStream(jfactlis.getPath());

				} catch (IOException e) {

					JOptionPane.showMessageDialog(null, "Ung�ltige Datei wurde ausgew�hlt...", "Error", 0);

				} catch (NumberFormatException e) {

					JOptionPane.showMessageDialog(null, "Ung�ltige Datei wurde ausgew�hlt...", "Error", 0);

				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		});

		t.start();       // Start des Threads
		t.interrupt(); 
						 /* Interrupt-Flag wird gesetzt*/

	}

}
